require('dotenv').config();
const { monitorMarket } = require('./apiHandler');
const { trade } = require('./tradingLogic');
const { trackProfitLoss } = require('./profitLossTracker');

async function runTradingBot() {
    console.log("Starting trading bot...");
    
    // Fetch stock data periodically and execute trades
    setInterval(async () => {
        const stockPrice = await monitorMarket();
        trade(stockPrice);
        trackProfitLoss();
    }, 10000); // Runs every 10 seconds
}

runTradingBot();
