let positions = [];
const buyThreshold = 0.98; // 2% drop
const sellThreshold = 1.03; // 3% rise

function trade(stockPrice) {
    const lastPrice = positions[positions.length - 1]?.price || stockPrice;
    
    if (stockPrice <= lastPrice * buyThreshold) {
        positions.push({ type: 'buy', price: stockPrice });
        console.log(`Bought stock at $${stockPrice}`);
    } else if (stockPrice >= lastPrice * sellThreshold && positions.some(pos => pos.type === 'buy')) {
        positions.push({ type: 'sell', price: stockPrice });
        console.log(`Sold stock at $${stockPrice}`);
    }
}

module.exports = { trade };
