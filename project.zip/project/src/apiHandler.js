const axios = require('axios');

async function monitorMarket() {
    try {
        const response = await axios.get(process.env.STOCK_API_URL);
        const stockPrice = response.data.price; // Assuming the API returns a 'price' field
        console.log(`Current stock price: $${stockPrice}`);
        return stockPrice;
    } catch (error) {
        console.error('Error fetching stock price:', error);
        return null;
    }
}

module.exports = { monitorMarket };
