let balance = 10000; // Starting with $10,000
let profitLoss = 0;

function trackProfitLoss() {
    // Placeholder logic for profit/loss tracking
    console.log(`Current balance: $${balance}`);
    console.log(`Profit/Loss: $${profitLoss}`);
}

module.exports = { trackProfitLoss };
