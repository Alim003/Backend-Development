module.exports = {
    stockApiUrl: process.env.STOCK_API_URL,
};
